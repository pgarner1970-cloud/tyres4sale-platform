<?php
include("functions/db.php");
include_once("functions/email_template.php");

// Registration: always create Trade users with usertype = 'T'
// Store company name in description and telephone in telephone.
// Generate otp_code and send verification email.

$success = "";
$error = "";

function sendVerificationEmail($toEmail, $username, $otp) {
    $baseUrl = "https://tradeconnect.tyres4sale.com";
    $verifyUrl = $baseUrl . "/verifyemail.php?u=" . urlencode($username) . "&code=" . urlencode($otp);

    $body  = "<p>Thanks for registering for Trade access.</p>";
    $body .= "<p>Please verify your email address by clicking the link below:</p>";
    $body .= "<p><a href='" . htmlspecialchars($verifyUrl, ENT_QUOTES, 'UTF-8') . "'>" . htmlspecialchars($verifyUrl, ENT_QUOTES, 'UTF-8') . "</a></p>";
    $body .= "<p>Or enter this verification code on the verification page: <b>" . htmlspecialchars($otp, ENT_QUOTES, 'UTF-8') . "</b></p>";
    $body .= "<p>Best regards<br>The LTC Team</p>";

    $subject = 'Verify your LTC Trade account';

    $html = function_exists('email_wrap_html') ? email_wrap_html($body, 'Verify your email') : $body;
    $headers = function_exists('email_headers') ? email_headers('webmaster@tyres4sale.com') : ("From: webmaster@tyres4sale.com\r\nMIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\n");

    @mail($toEmail, $subject, $html, $headers);
}

if (isset($_POST["operation"]) && $_POST["operation"] === "Add") {
    // Inputs from form
    $company = trim($_POST["company"] ?? "");
    $telephone = trim($_POST["telephone"] ?? "");
    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $passwordPlain = $_POST["userpass"] ?? "";

    if ($company === "" || $telephone === "" || $username === "" || $email === "" || $passwordPlain === "") {
        $error = "Please complete all required fields.";
    } else {
        // Create OTP (6 digits)
        $otp = str_pad((string)random_int(0, 999999), 6, "0", STR_PAD_LEFT);

        // Hash password
        $passwordHash = password_hash($passwordPlain, PASSWORD_DEFAULT);

        // Ensure username/email not already used
        $check = $conn->prepare("SELECT COUNT(id) FROM tblusers WHERE username=? OR email=?");
        $check->bind_param('ss', $username, $email);
        $check->execute();
        $checkRes = $check->get_result();
        $exists = (int)($checkRes->fetch_row()[0] ?? 0);
        $check->close();

        if ($exists > 0) {
            $error = "That username or email address is already in use.";
        } else {
            $usertype = 'T';
            $description = $company;

            $query = $conn->prepare("INSERT INTO tblusers (username, hash, usertype, description, email, otp_code, telephone) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $query->bind_param('sssssss', $username, $passwordHash, $usertype, $description, $email, $otp, $telephone);

            if ($query->execute()) {
                // Send verification email
                sendVerificationEmail($email, $username, $otp);

                $success = "Thanks, your account has been created. Please check your email to verify your address before logging in.";
            } else {
                $error = "An error occurred creating your account. Please try again.";
            }

            $query->close();
        }
    }
}

?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LTC Tyres - Register for Trade access</title>

    <!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/blurt.min.css" rel="stylesheet">

    <style>
        /* Better inline validation spacing (Bootstrap 3) */
        .form-group { margin-bottom: 18px; }
        .help-block.validation-msg { margin: 6px 0 0; }
    </style>

</head>

<body>
    <!-- Bootstrap core JavaScript -->
    <script src="js/blurt.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="js/registeracc.js"></script>

	<div class="container" style="margin-top: 5%;">
        <div class="col-md-6 col-md-offset-3"><img src="ltc_logo_600w.png" width="540px"></div>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-primary">
				<div class="panel-heading">Register for Trade</div>
				<div class="panel-body">

				<?php if (!empty($success)) { ?>
				  <div class="alert alert-success">
				    <?php echo htmlspecialchars($success); ?>
				    <div style="margin-top:6px;">Once verified, you can <a href="login.php">log in here</a>.</div>
				  </div>
				<?php } ?>
				<?php if (!empty($error)) { ?>
				  <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
				<?php } ?>

				<!-- Login Form -->
				<form role="form" method="post" action="registeracc.php" name="user_form" id="user_form">
                <input type="hidden" name="operation" id="operation" value="Add">
				<!-- Company Name Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="company"><span class="text-danger" style="margin-right:5px;">*</span>Company name:</label>
							<div class="input-group">
								<input class="form-control" id="company" type="text" name="company" placeholder="Company name" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

				<!-- Telephone Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="telephone"><span class="text-danger" style="margin-right:5px;">*</span>Telephone:</label>
							<div class="input-group">
								<input class="form-control" id="telephone" type="text" name="telephone" placeholder="Telephone number" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

				<!-- Username Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="username"><span class="text-danger" style="margin-right:5px;">*</span>Username:</label>
							<div class="input-group">
								<input class="form-control" id="username" type="text" name="username" placeholder="Username" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-user" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

				<!-- Password Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="userpass"><span class="text-danger" style="margin-right:5px;">*</span>Password:</label>
							<div class="input-group">
								<input class="form-control" id="userpass" type="password" name="userpass" placeholder="Password" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-asterisk" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

				<!-- Confirm Password Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="userpass"><span class="text-danger" style="margin-right:5px;">*</span>Confirm Password:</label>
							<div class="input-group">
								<input class="form-control" id="confpass" type="password" name="confpass" placeholder="Confirm Password" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-asterisk" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

				<!-- Email address Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="email"><span class="text-danger" style="margin-right:5px;">*</span>Email:</label>
							<div class="input-group">
								<input class="form-control" id="email" type="text" name="email" placeholder="Email address" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

				<!-- Email confirm address Field -->
					<div class="row">
						<div class="form-group col-xs-12">
						<label for="confemail"><span class="text-danger" style="margin-right:5px;">*</span>Confirm Email:</label>
							<div class="input-group">
								<input class="form-control" id="confemail" type="text" name="confemail" placeholder="Confirm Email address" required/>
								<span class="input-group-btn">
									<label class="btn btn-primary"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></label>
								</span>
								</span>
							</div>
						</div>
					</div>

					<!-- Login Button -->
					<div class="row">
						<div class="form-group col-xs-4">
							<button class="btn btn-primary" type="submit">Submit</button>
						</div>
					</div>
					<!-- server-side success/error messages are shown above the form -->
				</form>
				<!-- End of Login Form -->

			</div>
		</div>
		Back to login - <a href="login.php">Click here</a>
	</div>

    <!-- (Removed duplicate JS includes) -->


</body>

</html>
