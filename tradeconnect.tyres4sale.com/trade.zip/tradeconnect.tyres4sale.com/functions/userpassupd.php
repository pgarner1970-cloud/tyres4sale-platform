<?php
include('db.php');

if($_POST["operation"] == "upd") {
	$otp = $_POST["otp"];
	$newpass = $_POST["newpass"];
	$confpass = $_POST["confpass"];
	if($newpass == $confpass) {
	    $newhash = password_hash($newpass, PASSWORD_DEFAULT);
	    $query = $conn->prepare("UPDATE tblusers SET hash=?, otp_code=NULL WHERE otp_code=?");
	    $query->bind_param('ss', $newhash, $otp);
	    if($query->execute()) {
		    echo json_encode(["success" => true]);
	    } else {
		    echo json_encode(["success" => false, "message" => "Password update failed on query"]);
	    }
	} else {
        echo json_encode(["success" => false, "message" => "Password update failed here"]);
	}
}