<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">LTC Tyres</a>
    <ul class="navbar-nav me-auto">
      <li class="nav-item">
        <a class="nav-link" href="stock.php">Tyre Search</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="basket.php">Basket</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
    </ul>
  </div>
</nav>