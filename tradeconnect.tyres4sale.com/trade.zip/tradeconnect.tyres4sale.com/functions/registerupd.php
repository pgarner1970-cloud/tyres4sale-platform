<?php
include('db.php');

header('Content-Type: text/plain; charset=UTF-8');

// Backwards compatible endpoint for checking uniqueness.
// - POST username=<value> => echoes count (0 if available, >0 if taken)
// - POST email=<value>    => echoes count (0 if available, >0 if in use)
//
// This trade system stores users in tblusers (per Navicat screenshot).

if (isset($_POST['username']) && $_POST['username'] !== '') {
    $username = trim($_POST['username']);

    $stmt = $conn->prepare("SELECT COUNT(id) AS cnt FROM tblusers WHERE username=?");
    if (!$stmt) {
        http_response_code(500);
        echo "0";
        exit;
    }
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = 0;
    if ($result) {
        $row = $result->fetch_row();
        if ($row && isset($row[0])) $count = (int)$row[0];
    }
    $stmt->close();

    echo (string)$count;
    exit;
}

if (isset($_POST['email']) && $_POST['email'] !== '') {
    $email = trim($_POST['email']);

    $stmt = $conn->prepare("SELECT COUNT(id) AS cnt FROM tblusers WHERE email=?");
    if (!$stmt) {
        http_response_code(500);
        echo "0";
        exit;
    }
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = 0;
    if ($result) {
        $row = $result->fetch_row();
        if ($row && isset($row[0])) $count = (int)$row[0];
    }
    $stmt->close();

    echo (string)$count;
    exit;
}

// Nothing to check
echo "0";
