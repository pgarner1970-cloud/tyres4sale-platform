<?php
include("functions/db.php");

$success = "";
$error = "";

$username = trim($_GET['u'] ?? '');
$code = trim($_GET['code'] ?? '');

if ($username === '' || $code === '') {
  $error = "Invalid verification link.";
} else {
  // Confirm user exists and code matches
  $stmt = $conn->prepare("SELECT id, email, otp_code FROM tblusers WHERE username=? AND usertype='T' LIMIT 1");
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res ? $res->fetch_assoc() : null;
  $stmt->close();

  if (!$row) {
    $error = "No such user.";
  } elseif (empty($row['otp_code'])) {
    $success = "Your email is already verified. You can log in.";
  } elseif (hash_equals((string)$row['otp_code'], (string)$code)) {
    $upd = $conn->prepare("UPDATE tblusers SET otp_code=NULL WHERE id=?");
    $upd->bind_param('i', $row['id']);
    if ($upd->execute()) {
      $success = "Thanks, your email has been verified. You can now log in.";
    } else {
      $error = "Could not verify your email. Please try again.";
    }
    $upd->close();
  } else {
    $error = "Invalid verification code.";
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LTC Trade - Verify Email</title>
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link href="css/simple-sidebar.css" rel="stylesheet">
</head>
<body>
  <div class="container" style="margin-top: 5%; max-width: 720px;">
    <div class="text-center" style="margin-bottom: 20px;">
      <img src="ltc_logo_600w.png" width="540" alt="LTC Tyres">
    </div>

    <div class="panel panel-primary">
      <div class="panel-heading">Email Verification</div>
      <div class="panel-body">
        <?php if (!empty($success)) { ?>
          <div class="alert alert-success">
            <?php echo htmlspecialchars($success); ?>
            <div style="margin-top:8px;"><a class="btn btn-primary" href="login.php">Go to Login</a></div>
          </div>
        <?php } else { ?>
          <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
          <div style="margin-top:8px;">If you need a new verification email, please register again or contact LTC.</div>
        <?php } ?>
      </div>
    </div>

  </div>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>
