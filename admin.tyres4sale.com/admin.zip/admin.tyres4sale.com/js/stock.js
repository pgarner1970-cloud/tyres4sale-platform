	$(document).ready(function(){
		$("#wrapper").toggleClass("toggled");
		$.ajax({
			url: 'functions/list_width.php',
			type: 'post',
			success:function(response){

				var len = response.length;

				$("#width").empty();
				for( var i = 0; i<len; i++) {
					var widthDesc = response[i]['widthDesc'];

					$("#width").append("<option value='"+widthDesc+"'>"+widthDesc+"</option>");

				}
			}
		});
		$.ajax({
			url: 'functions/list_profile.php',
			type: 'post',
			success:function(response){

				var len = response.length;

				$("#profile").empty();
				for( var i = 0; i<len; i++){
					var profileDesc = response[i]['profileDesc'];

					$("#profile").append("<option value='"+profileDesc+"'>"+profileDesc+"</option>");

				}
			}
		});
		$.ajax({
			url: 'functions/list_rim.php',
			type: 'post',
			success:function(response){

				var len = response.length;

				$("#rim").empty();
				for( var i = 0; i<len; i++){
					var rimDesc = response[i]['rimDesc'];

					$("#rim").append("<option value='"+rimDesc+"'>"+rimDesc+"</option>");

				}
			}
		});
		$.ajax({
			url: 'functions/list_speed.php',
			type: 'post',
			success:function(response){

				var len = response.length;

				$("#speed").empty();
				$("#speed").append("<option value='*'>ALL</option>");
				for( var i = 0; i<len; i++){
					var speedDesc = response[i]['speedDesc'];

					$("#speed").append("<option value='"+speedDesc+"'>"+speedDesc+"</option>");

				}
			}
		});
		$.ajax({
			url: 'functions/list_manufacturers.php',
			type: 'post',
			success:function(response){

				var len = response.length;

				$("#manufacturer").empty();
				$("#manufacturer").append("<option value='*'>** ALL **</option>");
				for( var i = 0; i<len; i++){
					var Manufacturer = response[i]['Manufacturer'];

					$("#manufacturer").append("<option value='"+Manufacturer+"'>"+Manufacturer+"</option>");

				}
			}
		});		
		$("#search").submit(function(event) {
			$("#resultsDiv").empty();
			
			var formData = {
				't'		: 'enquiry',
				'w'		: $('#width option:selected').val(),
				'p'		: $('#profile option:selected').val(),
				'r'		: $('#rim option:selected').val(),
				's'		: $('#speed option:selected').val(),
				'f'		: $('#fuel option:selected').val(),
				'wg'	: $('#wetgrip option:selected').val()
			};
			console.log(formData);
			$.ajax({
				url: 'https://tyres4sale.com/_api/apiSearch.php',
				type: 'get',
				data: formData,
				dataType: 'json'
			})

				.done(function(data) {

				// log data to the console so we can see
				console.log(data); 
				var len = data.length;
				console.log(len);
				
				$("#resultsDiv").empty();
				var resultsHtml = "<table cellspacing=2 cellpadding=2 class='table table-striped'>";
				resultsHtml += '<thead><tr bgcolor=#cecece><td>EAN</td><td>Manufacturer</td><td>Description</td><td>Class</td><td>Supplier</td><td>Fuel</td><td>Wet</td><td>Noise</td><td>Buy</td><td>Sell (inc VAT)</td></tr></thead>';
				for(var i = 0; i<len; i++) {
					if (data[i]['Manufacturer'] != $('#manufacturer option:selected').val() && $('#manufacturer option:selected').val() != '*') {
						continue;
					}
					resultsHtml += '<tr><td>' + data[i]['EAN'] + '</td>';
					resultsHtml += '<td>' + data[i]['Manufacturer'] + '</td>';
					resultsHtml += '<td>' + data[i]['TyreDesc'] + '</td>';
					resultsHtml += '<td>' + data[i]['LTCClass'] + '</td>';
					resultsHtml += '<td>' + data[i]['Supplier'] + '</td>';
					resultsHtml += '<td>' + data[i]['RollingRes'] + '</td>';
					resultsHtml += '<td>' + data[i]['WetGrip'] + '</td>';
					resultsHtml += '<td>' + data[i]['NoisePerf'] + '</td>';
					resultsHtml += '<td>' + data[i]['UnitBuyPrice'] + '</td>';
					resultsHtml += '<td>' + data[i]['UnitPrice'] + '</td></tr>';
				} 
				resultsHtml += "</table>";
				$("#resultsDiv").html(resultsHtml);
			});
			event.preventDefault();
		});
	});	  