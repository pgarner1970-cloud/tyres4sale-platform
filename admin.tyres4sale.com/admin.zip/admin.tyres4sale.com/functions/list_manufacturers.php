<?php
include('db.php');
header('Content-type: application/json');

$sql = "SELECT distinct Manufacturer FROM tbltyredata ORDER BY Manufacturer ASC";

$result = mysqli_query($conn,$sql);

$results_arr = array();

while( $row = mysqli_fetch_array($result) ){
    $Manufacturer = $row['Manufacturer'];
    $results_arr[] = array("Manufacturer" => $Manufacturer);
}

// encoding array to json format
echo json_encode($results_arr);